/* GET contact view */
var contact = (req, res) => {
    res.render('index',{title: 'Travlr Getaways'});
};
module.exports = {
    contact
};